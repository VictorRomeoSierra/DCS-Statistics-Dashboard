<?php
/**
 * Server Status Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_servers_api.php';