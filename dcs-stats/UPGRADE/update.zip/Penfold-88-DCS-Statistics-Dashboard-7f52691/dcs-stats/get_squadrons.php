<?php
/**
 * Squadrons Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_squadrons_api.php';
