<?php
/**
 * Squadron Members Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_squadron_members_api.php';