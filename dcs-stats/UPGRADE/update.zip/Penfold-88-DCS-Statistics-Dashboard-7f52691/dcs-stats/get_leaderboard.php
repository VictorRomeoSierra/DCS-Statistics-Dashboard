<?php
/**
 * Get Leaderboard Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_leaderboard_api.php';
