<?php
/**
 * Squadron Credits Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_squadron_credits_api.php';