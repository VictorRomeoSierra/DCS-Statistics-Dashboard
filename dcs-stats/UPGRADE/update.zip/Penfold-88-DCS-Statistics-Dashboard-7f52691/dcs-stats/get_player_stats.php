<?php
/**
 * Get Player Stats Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_player_stats_api.php';
