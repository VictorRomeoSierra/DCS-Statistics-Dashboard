<?php
/**
 * Search Players Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/search_players_api.php';