<?php
/**
 * Get Mission Stats Endpoint
 * API-only implementation
 */

// Always use API version
include __DIR__ . '/get_missionstats_api.php';