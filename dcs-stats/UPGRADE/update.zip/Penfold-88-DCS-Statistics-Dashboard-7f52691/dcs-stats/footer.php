<footer>
  <p>&copy; 2025 DCS Stats | Powered by <a href="https://skypirates.uk" target="_blank">SkyPirates</a> & <a href="https://503rdblacksheep.com" target="_blank">{503rd} Blacksheep</a></p>
</footer>
</body>
</html>
